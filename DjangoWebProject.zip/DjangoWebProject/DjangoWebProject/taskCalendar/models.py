﻿# coding:utf-8
from django.db import models


# 測定局動作ログ
class Taskinfost(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    measdate = models.DateField()
    noise_regdate = models.DateTimeField(blank=True, null=True)
    noise_flag = models.DecimalField(max_digits=1, decimal_places=0)
    lae_regdate = models.DateTimeField(blank=True, null=True)
    lae_flag = models.DecimalField(max_digits=1, decimal_places=0)
    environ_regdate = models.DateTimeField(blank=True, null=True)
    environ_flag = models.DecimalField(max_digits=1, decimal_places=0)
    rd90_regdate = models.DateTimeField(blank=True, null=True)
    rd90_flag = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd100_regdate = models.DateTimeField(blank=True, null=True)
    rd100_flag = models.IntegerField()
    modes_regdate = models.DateTimeField(blank=True, null=True)
    modes_flag = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sbm_regdate = models.DateTimeField(blank=True, null=True)
    sbm_flag = models.DecimalField(max_digits=1, decimal_places=0)
    noise_rd100_regdate = models.DateTimeField(blank=True, null=True)
    noise_rd100_flag = models.DecimalField(max_digits=1, decimal_places=0)
    onfit_regdate = models.DateTimeField(blank=True, null=True)
    onfit_flag = models.DecimalField(max_digits=1, decimal_places=0)
    adjust_regdate = models.DateTimeField(blank=True, null=True)
    adjust_flag = models.DecimalField(max_digits=1, decimal_places=0)
    listen_regdate = models.DateTimeField(blank=True, null=True)
    listen_flag = models.DecimalField(max_digits=1, decimal_places=0)
    fixed_regdate = models.DateTimeField(blank=True, null=True)
    fixed_flag = models.DecimalField(max_digits=1, decimal_places=0)
    stats_regdate = models.DateTimeField(blank=True, null=True)
    stats_flag = models.DecimalField(max_digits=1, decimal_places=0)

    class Meta:
        managed = False
        db_table = 'taskinfost'
        unique_together = (('icao', 'stationid', 'measdate'),)

# 測定期間情報
class Stationspan(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    startdate = models.DateTimeField()
    enddate = models.DateTimeField()
    modelno = models.DecimalField(max_digits=2, decimal_places=0)
    noiseavailable = models.DecimalField(max_digits=1, decimal_places=0)
    rd90available = models.DecimalField(max_digits=1, decimal_places=0)
    modesavailable = models.DecimalField(max_digits=1, decimal_places=0)
    rd100available = models.DecimalField(max_digits=1, decimal_places=0)
    sd100available = models.DecimalField(max_digits=1, decimal_places=0)
    sbmsid = models.CharField(max_length=4, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'stationspan'
        unique_together = (('icao', 'stationid', 'startdate'),)

# 欠測期間情報
class Missspan(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    starttime = models.DateTimeField()
    endtime = models.DateTimeField(blank=True, null=True)
    noise = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd90 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    modes = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd100 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sd100 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sbm = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    reason = models.DecimalField(max_digits=2, decimal_places=0, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'missspan'
        unique_together = (('icao', 'stationid', 'starttime'),)
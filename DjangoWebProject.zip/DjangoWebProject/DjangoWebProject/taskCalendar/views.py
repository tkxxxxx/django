﻿# coding:utf-8
from django.shortcuts import render
from taskCalendar.taskTable import *
from datetime import datetime as dt
from django.http.response import JsonResponse

import datetime
import calendar
import time
import json

# 画面初期表示
def taskCalendar_Load(request):

    # iniファイルを読み取り、マップを生成する。
    fileMap = loadIniFile()
    
    # 空港コードを取得する。
    icao = fileMap["Master"]["ICAO"]

    # 測定局情報の取得・測定局リストへの初期セット
    stationInfo = getStationInfo(icao)

    # 凡例表示
    remarksList = setRemarks(fileMap)

    # 現在の時間を取得する。
    tDate = datetime.date.today()

    # 選択日付のタスク情報を取得する。
    fillTaskTable(tDate, stationInfo, fileMap)

    # ［各局の進捗状況］リストを更新する
    setdgvStationTaskList(tDate, stationInfo, fileMap)

    content = {'stationInfo': stationInfo, 'remarks': remarksList}

    return render(request, 'taskCalendar/taskCalendar.html', content)

# タスクカレンダーの更新
def setCalendar(request):

    # iniファイルを読み取り、マップを生成する。
    fileMap = loadIniFile()
    
    # 空港コードを取得する。
    icao = fileMap["Master"]["ICAO"]

    # 現在の時間を取得する。
    tDate = datetime.date.today()

    # Ajaxからパラメータを取得する。
    sDate = request.GET.get('sDate')

    if sDate:
        tDate = dt.strptime(sDate, '%Y-%m-%d')

    # 測定局情報の取得・測定局リストへの初期セット
    stationInfo = getStationInfo(icao)

    # 月初日を取得する。
    tStartDate = tDate.replace(day=1)

    # 月の日数を取得する。
    monthDay = calendar.monthrange(tDate.year, tDate.month)[1]

    calendarInfo = {}

    for iDayIdx in range(monthDay):
        
        # 日付を設定する。
        date = tStartDate + datetime.timedelta(iDayIdx)

        # yyyymmddに変換
        sDate = date.strftime('%Y-%m-%d')

        map = {}
        calendarInfo[sDate] = map

        # カレンダーの情報を取得する。
        nTask = fillTaskTable(date, stationInfo, fileMap)

        # カレンダーの背景色を取得する。
        backColor = getBackColor(nTask, fileMap)

        # カレンダーのテキスト色を取得する。
        foreColor = getForeColor(nTask, fileMap)

        if backColor != "White":
            # 背景色
            map["backColor"] = backColor

        if foreColor != "Black":
            # テキスト色
            map["foreColor"] = foreColor
        

    # 選択日付のタスク情報を取得する。
    #fillTaskTable(tDate, stationInfo, fileMap)

    response = {'calendarInfo': calendarInfo}

    return JsonResponse(response)

# Ajaxメソッド、各局の進捗状況を再描画
def stationSelect(request):

    # iniファイルを読み取り、マップを生成する。
    fileMap = loadIniFile()
    
    # 空港コードを取得する。
    icao = fileMap["Master"]["ICAO"]

    # 現在の時間を取得する。
    tDate = datetime.date.today()

    # Ajaxからパラメータを取得する。
    stationList = json.loads(request.POST.get('stationList'))

    # Ajaxから選択日を取得する。
    selected_date = stationList['selected_date']

    if selected_date:
        # timestamp型に変換
        tDate = dt.strptime(selected_date, '%Y-%m-%d')

    # 測定局情報の取得・測定局リストへの初期セット
    stationInfo = getStationInfo(icao)

    # 選択日付のタスク情報を取得する。
    fillTaskTable(tDate, stationInfo, fileMap)

    # ［各局の進捗状況］リストを更新する
    setdgvStationTaskList(tDate, stationInfo, fileMap)
    
    # チェックボックスのステータスを設定する。
    for info in stationInfo:
        for key in stationList:
            if info['stationId'] == key:
                info['selected'] = int(stationList[key])
                break

    response = {'stationInfo': stationInfo}

    return JsonResponse(response)

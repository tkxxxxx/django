from django.apps import AppConfig


class taskCalendarConfig(AppConfig):
    name = 'taskCalendar'

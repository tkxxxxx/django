﻿from django.urls import path
from . import views

app_name = 'taskCalendar'

urlpatterns = [path('', views.taskCalendar_Load, name='taskCalendar_Load'),
               path('stationSelect/', views.stationSelect, name='stationSelect'),
               path('setCalendar/', views.setCalendar, name='setCalendar')]

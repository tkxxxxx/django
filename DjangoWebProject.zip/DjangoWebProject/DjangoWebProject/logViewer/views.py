﻿# coding:utf-8
from django.shortcuts import render
from logViewer.models import *
from django.core.paginator import Paginator
from django.conf import settings
from django.http.response import JsonResponse
from django.core import serializers
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

import os
import json
import datetime

'''
 画面初期表示
'''
def logViewer_Load(request):

    # iniファイルを読み取り
    dispCount = loadIniFile()

    # エラーログ初期リード
    content = errorLogLoad({})

    if len(content['pageInfo']) == 0:
        # データが存在しない場合
        content['disabledFlg'] = True
    else:
        for info in content['pageInfo']:
            # 発生日時の変換
            date = info.logdate
            info.logdate = str(info.logdate).replace("-", "/")
        
    return render(request, "logViewer/logViewer.html", content)

'''
 ［絞り込み］ボタンクリック
'''
@csrf_exempt
def btnFilter_Click(request):

    # iniファイルを読み取り
    dispCount = loadIniFile()

    # Ajaxからパラメータを取得する。
    param = json.loads(request.POST.get('param'))

    # エラーログ初期リード
    content = errorLogLoad(param)

    content['pageInfo'] = serializers.serialize("json", content['pageInfo'], ensure_ascii=False)

    return JsonResponse(content)

'''
 ［絞り込み解除］ボタンクリック
'''
def btnResetFilter_Click(request):

    # iniファイルを読み取り
    dispCount = loadIniFile()

    # エラーログ初期リード
    content = errorLogLoad({})

    content['pageInfo'] = serializers.serialize("json", content['pageInfo'], ensure_ascii=False)

    return JsonResponse(content)

'''
 ページボタンクリック
'''
@csrf_exempt
def pageBtn_Click(request):

    # Ajaxからパラメータを取得する。
    param = json.loads(request.POST.get('param'))

    if param['searchFlg'] is False:
        # 絞り込みボタンを押下しない場合
        param['searchName'] = ""
        param['searchVal'] = ""

    # ページ数
    pageNum = int(param.get('pageNum', 1))

    # 押下ボタン
    pageBtn = param['pageBtn']

    # 最大ページ
    maxPage = int(param.get('maxPage', 1))

    if pageBtn == "prePage":
        pageNum -= 1

    elif pageBtn == "nextPage":
        pageNum += 1

    elif pageBtn == "fristPage":
        pageNum = 1

    elif pageBtn == "lastPage":
        pageNum = maxPage

    # ページ数
    param['pageNum'] = pageNum

    # エラーログ初期リード
    content = errorLogLoad(param)

    content['pageInfo'] = serializers.serialize("json", content['pageInfo'], ensure_ascii=False)

    response = {'content': content}

    return JsonResponse(content)


'''
 [タブ区切りテキスト出力]ボタンクリックイベント
'''
@csrf_exempt
def download(request):

    # Ajaxからパラメータを取得する。
    param = json.loads(request.POST.get('param'))

    if param['searchFlg'] is False:
        # 絞り込みボタンを押下しない場合
        param['searchName'] = ""
        param['searchVal'] = ""

    # エラーログ初期リード
    content = errorLogLoad(param)

    content['pageInfo'] = serializers.serialize("json", content['pageInfo'], ensure_ascii=False)
    response = HttpResponse(content['pageInfo'], content_type="text/plain")
    return response

'''
 エラーログ初期リード
'''
def errorLogLoad(param):

    # iniファイルを読み取り
    dispCount = loadIniFile()

    content = {}

    # 絞り込み条件
    searchName = param.get('searchName', "")

    # 絞り込み値
    searchVal = param.get('searchVal', "")

    # ページ数
    pageNum = int(param.get('pageNum', 1))

    # エラーログのデータを取得する。
    detailList = Errorlog.objects.all().order_by('-keyno')
    
    if searchName == "logDate":
        # 発生日時の場合

        # 日付（から）
        dateFrom = param.get('dateFrom')

        # 日付（まで）
        dateTo = param.get('dateTo')

        # timestamp型に変換
        tDate = datetime.datetime.strptime(dateTo, '%Y-%m-%d')

        # 翌日を取得する。
        nextDay = tDate + datetime.timedelta(1)

        # 発生日時
        detailList = detailList.filter(logdate__gte = dateFrom, logdate__lt = nextDay)

    else:
        # 絞り込みを入力する場合
        if searchVal != "":
            if searchName == "keyNo":
                # No
                detailList = detailList.filter(keyno = int(searchVal))
            elif searchName == "level":
                # レベル
                detailList = detailList.filter(level = int(searchVal))
            elif searchName == "number":
                # エラー番号
                detailList = detailList.filter(number = int(searchVal))
            elif searchName == "description":
                # エラー内容
                detailList = detailList.filter(description__contains = str(searchVal))
            elif searchName == "computerName":
                # 端末名
                detailList = detailList.filter(computername__contains = str(searchVal))
                print("端末名")
            elif searchName == "user":
                # ユーザ名
                detailList = detailList.filter(user__contains = str(searchVal))
            elif searchName == "application":
                # 発生ソフトウェア
                detailList = detailList.filter(application__contains = str(searchVal))
            elif searchName == "source":
                # エラー箇所
                detailList = detailList.filter(source__contains = str(searchVal))
            elif searchName == "memo":
                # 備考
                detailList = detailList.filter(memo__contains = str(searchVal))

    # ページ分割
    pageList = Paginator(detailList, dispCount)

    # 該当ページの情報
    pageInfo = pageList.page(pageNum)

    # 明細内容
    content['pageInfo'] = pageInfo.object_list

    # エラー番号が存在しない場合
    for info in content['pageInfo']:
        number = info.number
        if number is None and number != 0:
            info.number = ""

    # ページ数
    content['pageNum'] = pageNum

    # ページ開始件数
    content['start_index'] = pageInfo.start_index()

    # ページ終了件数
    content['end_index'] = pageInfo.end_index()

    # 前ページが存在するかどうか
    content['has_previous'] = pageInfo.has_previous()

    # 後ページが存在するかどうか
    content['has_next'] = pageInfo.has_next()

    # 総件数
    content['page_count'] = pageList.count

    # 総ページ数
    content['maxPage'] = pageList.num_pages

    return content

'''
 iniファイルを読み取り
'''
def loadIniFile():

    # 1ページあたりの表示件数
    dispCount = 100

    # ファイルパス
    FILE_DIR = os.path.join(settings.BASE_DIR, 'bin')
    file = 'LogViewer.ini'
    path = os.path.join(FILE_DIR, file)

    # ファイルを読み取り
    with open(path) as file_object:
        lines = file_object.readlines()

    for line in lines:
        # 改行コードを除く
        line = line.strip()

        if line.startswith("DispCount"):
            # 文字列の分割
            tempList = line.split("=")

            if len(tempList) > 1:
                dispCount = tempList[1]
                break

    return dispCount
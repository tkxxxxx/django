﻿from django.urls import path
from . import views

app_name = 'logViewer'

urlpatterns = [path('', views.logViewer_Load, name='logViewer_Load'),
               path('btnFilter_Click/', views.btnFilter_Click, name='btnFilter_Click'),
               path('btnResetFilter_Click/', views.btnResetFilter_Click, name='btnResetFilter_Click'),
               path('pageBtn_Click/', views.pageBtn_Click, name='pageBtn_Click'),
               path('download/', views.download, name='download'),]

﻿# coding:utf-8
from django.db import models

# エラーログ
class Errorlog(models.Model):
    keyno = models.AutoField(primary_key=True)
    logdate = models.DateTimeField(blank=True, null=True)
    icao = models.CharField(max_length=4)
    level = models.IntegerField(blank=True, null=True)
    number = models.IntegerField(blank=True, null=True)
    description = models.CharField(max_length=1024, blank=True, null=True)
    computername = models.CharField(max_length=30, blank=True, null=True)
    user = models.CharField(max_length=30, blank=True, null=True)
    application = models.CharField(max_length=255, blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    memo = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'errorlog'

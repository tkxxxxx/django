﻿from django.urls import path
from . import views, editStationViews, editSpanViews, sirenCutViews, editSirenCutViews

app_name = 'stationEdit'

urlpatterns = [path('', views.editMaster_Load, name='editMaster_Load'),
               path('lvwStation_Click/', views.lvwStation_Click, name='lvwStation_Click'),
               path('buttonControl/', views.buttonControl, name='buttonControl'),
               path('spanBtnControl/', views.spanBtnControl, name='spanBtnControl'),
               path('upDown_Click/', views.upDown_Click, name='upDown_Click'),
               path('del_Click/', views.del_Click, name='del_Click'),
               path('spanDel_Click/', views.spanDel_Click, name='spanDel_Click'),
               path('resetWindow/', views.resetWindow, name='resetWindow'),
               path('resetSpanWindow/', views.resetSpanWindow, name='resetSpanWindow'),
               path('saveIndex/', views.saveIndex, name='saveIndex'),
               path('editStation/<stationId>/<int:mode>/<int:index>/', editStationViews.editStation_Load, name='editStation_Load'),
               path('editStation/<stationId>/<int:mode>/<int:index>/pUpDown/', editStationViews.pUpDown, name='pUpDown'),
               path('editStation/<stationId>/<int:mode>/<int:index>/edit_Click/', editStationViews.edit_Click, name='edit_Click'),
               path('editStation/<stationId>/<int:mode>/<int:index>/isExistsStationList/', editStationViews.isExistsStationList, name='isExistsStationList'),
               path('editSpan/<stationId>/<int:mode>/<startDate>/', editSpanViews.editSpan_Load, name='editSpan_Load'),
               path('editSpan/<stationId>/<int:mode>/<startDate>/edit_Click/', editSpanViews.edit_Click, name='edit_Click'),
               path('editSpan/<stationId>/<int:mode>/<startDate>/isDoubleBooking/', editSpanViews.isDoubleBooking, name='isDoubleBooking'),
               path('editSpan/<stationId>/<int:mode>/<startDate>/checkAddressSpan/', editSpanViews.checkAddressSpan, name='checkAddressSpan'),
               path('editSpan/<stationId>/<int:mode>/<startDate>/setupEdit/', editSpanViews.setupEdit, name='setupEdit'),
               path('sirenCut_Click/<stationId>/', sirenCutViews.sirenCut_Load, name='sirenCut_Load'),
               path('sirenCut_Click/<stationId>/delete_Click/', sirenCutViews.delete_Click, name='delete_Click'),
               path('sirenCut_Click/<stationId>/resetSirenCutWindow/', sirenCutViews.resetSirenCutWindow, name='resetSirenCutWindow'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/', editSirenCutViews.editSirenCut_Load, name='editSirenCut_Load'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/edit_Click/', editSirenCutViews.edit_Click, name='edit_Click'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/isExists/', editSirenCutViews.isExists, name='isExists'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/<startDate>/<startTime>/', editSirenCutViews.editSirenCut_Load, name='editSirenCut_Load'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/<startDate>/<startTime>/edit_Click/', editSirenCutViews.edit_Click, name='edit_Click'),
               path('sirenCut_Click/<stationId>/editSirenCut/<int:mode>/<startDate>/<startTime>/isExists/', editSirenCutViews.isExists, name='isExists'),]

﻿# coding:utf-8
from stationEdit.models import *
from django.db import connection
from django.conf import settings
import xml.etree.ElementTree as et

import os
import datetime

'''
 空港情報の取得
'''
def getAirportInfo(sICAO):

    # 空港情報を取得する
    airportList = Airportlist.objects.filter(icao = sICAO)

    return airportList

'''
 測定局情報を取得する。
'''
def get_lvwStation(sICAO):

    lstRet = []
    
    # 測定局情報を取得する。
    stationList = Stationlist.objects.filter(icao = sICAO).order_by('sortkey')

    if len(stationList) > 0:
        # データが存在する場合

        for list in stationList:

            # 測定住所情報を取得する。
            span = Addressspan.objects.filter(icao = sICAO, stationid = list.stationid).order_by('-startdate')

            if len(span) > 0:
                # データが存在する場合

                tempMap = {}

                # 1：測定局ID
                tempMap['stationId'] = span[0].stationid

                # 2：測定局通称
                tempMap['shortName'] = span[0].shortname
    
                # 3：測定局種別
                permPortable = span[0].permorportable

                if permPortable == 0:
                    tempMap['permPortable'] = "固定局"
                elif permPortable == 1:
                    tempMap['permPortable'] = "移動局"
                elif permPortable == 2:
                    tempMap['permPortable'] = "周辺局"

                # 4：ソートキー
                tempMap['sortkey'] = list.sortkey

                lstRet.append(tempMap)

    return lstRet

'''
 測定期間情報を取得する。
'''
def get_lvwSpan(sICAO, stationId, xmlList):

    lvwSpan = []

    # 測定期間情報のＳＱＬ文を取得する。
    sql = getStationSpanSql(xmlList)

    # 測定期間情報を取得する。
    with connection.cursor() as cursor:
        cursor.execute(sql, [sICAO, stationId])

        for row in cursor:

            map = {}

            ## 測定開始日時
            startDate = "----/--/--"
            if row[1]:
                startDate = row[1].strftime('%Y/%m/%d')
            map['startDate'] = startDate
            map['startDateHidden'] = row[1].strftime('%Y-%m-%d %H:%M:%S')

            ## 測定終了日時
            endDate = "----/--/--"
            if row[2]:
                endDate = row[2].strftime('%Y/%m/%d')
            map['endDate'] = endDate
            map['endDateHidden'] = row[2].strftime('%Y-%m-%d %H:%M:%S')

            # 測定器型式名称
            map['modelName'] = row[3]

            info = []
            j = 4

            for xml in xmlList:
                
                val = ""

                if row[j] == -1:
                    val = "○"

                    if xml.get('name') == "Noise":
                        map['sirenCut'] = False

                info.append(val)
                
                j += 1

            map['available'] = info

            # 備考
            map['memo'] = row[-1]

            # リストに追加
            lvwSpan.append(map)

    return lvwSpan

'''
 測定期間情報のＳＱＬ文を取得する。
'''
def getStationSpanSql(xmlList):
    sql = 'SELECT'
    sql += '  a.StationID, '
    sql += '  a.StartDate, '
    sql += '  a.EndDate, '
    sql += '  b.ModelName, '

    for xml in xmlList:
        sql += 'a.' + xml.get('name') + 'Available, '

    sql += '  a.Memo '
    sql += 'FROM '
    sql += '  StationSpan AS a, '
    sql += '  ModelList AS b '
    sql += 'WHERE '
    sql += '  a.ModelNo = b.ModelNo '
    sql += '  AND a.ICAO = %s '
    sql += '  AND a.StationID = %s '
    sql += '  AND b.ModelAvailable = -1 '
    sql += 'ORDER BY '
    sql += '  a.StartDate DESC'
    return sql

'''
 アプリケーション設定値の取得（xmlファイルより）
'''
def loadXmlFile():

    xmlList = []

    # ファイルパスを設定する。
    FILE_DIR = os.path.join(settings.BASE_DIR, 'bin')
    file = 'StationEditConfig.xml'
    path = os.path.join(FILE_DIR, file)

    # ファイルを読み取り
    with open(path) as file:
        data = file.read()

    elem = et.fromstring(data)

    for e in elem.iter('Item'):

        map = {}

        map['name'] = e.find('Name').text
        map['caption'] = e.find('Caption').text
        map['description'] = e.find('Description').text
        map['setup'] = e.find('Setup').text
        map['setupTable'] = e.find('SetupTable').text

        cList = []

        for check in e.iter('DataCheck'):
            cMap = {}
            cMap['tableName'] = check.find('TableName').text
            cMap['startTime'] = check.find('StartTime').text
            cMap['endTime'] = check.find('EndTime').text
            cList.append(cMap)
        
        map['dataCheck'] = cList

        xmlList.append(map)

    return xmlList

''' 指定スケジュールが削除可能か
 <param name="sICAO">空港CD（ICAO）</param>
 <param name="sStationID">測定局ID</param>
 <param name="tSDate">開始日</param>
 <param name="tEDate">終了日</param>
 <param name="xmlList">データチェッククラスオブジェクト</param>
 <returns>判定結果（True：削除可能/False：削除不可）</returns>
'''
def deletableSpan(sICAO, sStationID, tSDate, tEDate, xmlList):

    # MissSpanのチェック
    if isExistsMissSpan(sICAO, sStationID, tSDate, tEDate):
        return False

    # TaskInfoStのチェック
    if isExistsTaskInfoSt(sICAO, sStationID, tSDate, tEDate):
        return False

    # 測定データ存在チェック
    for item in xmlList:
        dataCheck = item.get('dataCheck', "")
        for check in dataCheck:
            if isExistsMeasData(sICAO, sStationID, tSDate, tEDate, check):
                return False

    return True

''' 測定局の欠測情報が存在するかを判定し、返す
 <param name="sICAO">空港CD（ICAO）</param>
 <param name="sStationID">測定局ID</param>
 <param name="tSDate">開始日</param>
 <param name="tEDate">終了日</param>
 <returns>True：存在/False：存在しない</returns>
'''
def isExistsMissSpan(sICAO, sStationID, tSDate, tEDate):

    bRet = False

    list = Missspan.objects.filter(icao = sICAO, stationid = sStationID, starttime__gte = tSDate, endtime__lte = tEDate)

    if len(list) > 0:
        bRet = True

    return bRet

''' 測定局別確定情報取得
    完了しているかは別としてレコードが存在しているかどうかを調べる
 <param name="sICAO">空港CD（ICAO）</param>
 <param name="sStationID">測定局ID</param>
 <param name="tSDate">開始日</param>
 <param name="tEDate">終了日</param>
 <returns>True：存在/False：存在しない</returns>
'''
def isExistsTaskInfoSt(sICAO, sStationID, tSDate, tEDate):

    bRet = False

    startDate = datetimeToDate(tSDate)
    endDate = datetimeToDate(tEDate)

    list = Taskinfost.objects.filter(icao = sICAO, stationid = sStationID, measdate__gte = startDate, measdate__lte = endDate)

    if len(list) > 0:
        bRet = True

    return bRet

''' 対象期間の測定データが存在するか判定し、返す
 <param name="sICAO">空港CD（ICAO）</param>
 <param name="sStationID">測定局ID</param>
 <param name="tSDate">開始日</param>
 <param name="tEDate">終了日</param>
 <param name="dataCheck">データチェッククラスオブジェクト</param>
 <returns>True：存在/False：存在しない</returns>
'''
def isExistsMeasData(sICAO, sStationID, tSDate, tEDate, dataCheck):

    bRet = False

    tableName = str(dataCheck.get('tableName'))
    startTime = str(dataCheck.get('startTime'))
    endTime = str(dataCheck.get('endTime'))

    sql = 'SELECT COUNT(*) '
    sql += 'FROM '
    sql += tableName
    sql += ' WHERE '
    sql += '  ICAO = %s '
    sql += '  AND StationID = %s '
    sql += '  AND ' + startTime + ' >= %s '
    sql += '  AND ' + endTime + ' < %s '

    # 翌日を取得する。
    endDate = tEDate + datetime.timedelta(1)

    with connection.cursor() as cursor:
        cursor.execute(sql, [sICAO, sStationID, tSDate, endDate])
        row = cursor.fetchone()

        if row[0] > 0:
            bRet = True

    return bRet

def strToDatetime(tstr):
    tdatetime = datetime.datetime.strptime(tstr, '%Y-%m-%d %H:%M:%S')
    return tdatetime

def strToDatetimeWithoutHMS(tstr):
    tdatetime = datetime.datetime.strptime(tstr, '%Y-%m-%d')
    return tdatetime

def datetimeToDate(tdatetime):
    tdate = datetime.date(tdatetime.year, tdatetime.month, tdatetime.day)
    return tdate

'''
 YYYY-MM-DDの日付を返却する。
'''
def datetimeTostr(date):
    return str(date.strftime('%Y-%m-%d'))

def addDays(date, num):
    return date + datetime.timedelta(num)

def getNowTime():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
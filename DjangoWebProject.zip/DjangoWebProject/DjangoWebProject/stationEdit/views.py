﻿# coding:utf-8
from django.shortcuts import render
from stationEdit.stationEdit import *
from stationEdit.editStationViews import *
from django.http.response import JsonResponse

import datetime

SystemMinDate = "2001-01-01 00:00:00"
SystemMaxDate = "2100-12-31 23:59:59"

'''
 画面初期表示
'''
def editMaster_Load(request):

    content = {}

    # アプリケーション設定値を取得する。
    xmlList = loadXmlFile()
    content['xmlList'] = xmlList
    request.session['xmlList'] = xmlList

    # 空港コード
    sICAO = request.session.get('sICAO', "")

    if sICAO == "":
        sICAO = request.GET.get('icao', "")

    if sICAO == "":
        # データが存在しない場合
        return render(request, "editMaster.html", content)

    # 空港名
    airportName = ""

    # 空港情報を取得する。
    airportList = getAirportInfo(sICAO)

    if len(airportList) > 0:
        # データが存在する場合
        airportName = airportList[0].airportname

    content['airportName'] = airportName

    content['sICAO'] = sICAO

    request.session['SystemMinDate'] = SystemMinDate
    request.session['SystemMaxDate'] = SystemMaxDate

    # 測定局情報を取得する。
    lvwStation = get_lvwStation(sICAO)

    if len(lvwStation) == 0:
        return render(request, "editMaster.html", content)

    request.session['sICAO'] = sICAO

    # 測定局ID
    stationId = lvwStation[0].get('stationId')

    content['stidHidden'] = stationId

    if len(lvwStation) > 1:
        # 次の測定局ID
        nextStidHidden = lvwStation[1].get('stationId')
        content['nextStidHidden'] = nextStidHidden

    # 測定期間情報を取得する。
    lvwSpan = get_lvwSpan(sICAO, stationId, xmlList)
    
    content['lvwStation'] = lvwStation
    
    content['lvwSpan'] = lvwSpan

    # 測定局インデックス
    stationIndex = request.session.get('stationIndex', 0)

    content['stationIndex'] = stationIndex
    request.session['stationIndex'] = 0

    return render(request, "editMaster.html", content)

'''
 測定局リストボックスクリック時処理
'''
def lvwStation_Click(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = request.GET.get('stationId')

    content = {}

    # アプリケーション設定値を取得する。
    xmlList = request.session.get('xmlList')

    # 測定期間情報を取得する。
    lvwSpan = get_lvwSpan(sICAO, stationId, xmlList)

    content['lvwSpan'] = lvwSpan

    return JsonResponse(content)

'''
 ボタン制御
'''
def buttonControl(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局情報のボタン制御（True：使用不可、False：使用可）
    btnControl = {'stDetail': True, 
                  'stEdit': True, 
                  'stAdd': True, 
                  'stDel': True, 
                  'up':True, 
                  'down': True,
                  'spanEdit':True, 
                  'spanAdd':True,
                  'spanDel':True, 
                  'sirenCut':True
                  }

    # 測定局情報を取得する。
    lvwStation = get_lvwStation(sICAO)

    if len(lvwStation) == 0:
        # データが存在しない場合
        return JsonResponse(btnControl)

    else:

        # アプリケーション設定値を取得する。
        xmlList = request.session.get('xmlList')

        # 「詳細をみる」ボタン（False：使用可）
        btnControl['stDetail'] = False
        # 「追加」ボタン（False：使用可）
        btnControl['stAdd'] = False
        # 「追加」ボタン（False：使用可）
        btnControl['spanAdd'] = False

        # 測定局ID
        stationId = request.GET.get('stationId', "")

        for st in lvwStation:
            if stationId == st.get('stationId'):
                if st.get('permPortable') == "移動局":
                    # 測定局情報の編集ボタン（False：使用可）
                    btnControl['stEdit'] = False

                    if deletableSpan(sICAO, stationId, strToDatetime(SystemMinDate), strToDatetime(SystemMaxDate), xmlList):
                        # 測定局情報の削除ボタン（False：使用可）
                        btnControl['stDel'] = False

                break

        if len(lvwStation) > 1:
            # 上へボタン（False：使用可）
            btnControl['up'] = False
            # 下へボタン（False：使用可）
            btnControl['down'] = False

            if stationId == lvwStation[0].get('stationId'):
                # 上へボタン（True：使用不可）
                btnControl['up'] = True

        if stationId == lvwStation[-1].get('stationId'):
            # 最後のデータの場合

            # 下へボタン（True：使用不可）
            btnControl['down'] = True

        # 測定開始日
        startDate = request.GET.get('startDate')

        # 測定終了日
        endDate = request.GET.get('endDate')

        # 測定期間情報のボタン制御
        spanControl(btnControl, sICAO, stationId, startDate, endDate, xmlList)

    return JsonResponse(btnControl)

'''
 測定期間情報のボタン制御
'''
def spanBtnControl(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局情報のボタン制御（True：使用不可、False：使用可）
    btnControl = {'spanEdit':True, 
                  'spanAdd':False, 
                  'spanDel':True, 
                  'sirenCut':True
                  }

    # 測定局ID
    stationId = request.GET.get('stationId')

    # 測定開始日
    startDate = request.GET.get('startDate')

    # 測定終了日
    endDate = request.GET.get('endDate')

    # アプリケーション設定値を取得する。
    xmlList = request.session.get('xmlList')

    # 測定期間情報のボタン制御
    spanControl(btnControl, sICAO, stationId, startDate, endDate, xmlList)

    return JsonResponse(btnControl)

'''
 測定局［上へ］、［下へ］ボタンクリック
'''
def upDown_Click(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = request.GET.get('stationId', "")

    # 別の測定局ID
    changeStationId = request.GET.get('changeStationId', "")

    # 選択しているレコードを検索する。
    stationInfo = Stationlist.objects.filter(icao = sICAO, stationid = stationId)

    # 交換するレコードを検索する。
    changeInfo = Stationlist.objects.filter(icao = sICAO, stationid = changeStationId)

    # 選択しているレコードのSortKey
    sort_key = stationInfo[0].sortkey

    # 交換するレコードのSortKey
    change_key = changeInfo[0].sortkey

    # 現在の時間を取得する。
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 選択しているレコードを更新する
    stationInfo.update(sortkey = change_key, lastupdated = now)

    # 別のレコードを更新する
    changeInfo.update(sortkey = sort_key, lastupdated = now)

    # 測定局情報を取得する。
    lvwStation = get_lvwStation(sICAO)

    return JsonResponse({'lvwStation': lvwStation})
        
'''
 測定期間情報のボタン制御
'''
def spanControl(btnControl, sICAO, stationId, startDate, endDate, xmlList):

    # 測定期間情報を取得する。
    lvwSpan = get_lvwSpan(sICAO, stationId, xmlList)

    if len(lvwSpan) > 0:
            
        # 空港情報を取得する。
        airportList = getAirportInfo(sICAO)

        # 測定開始日
        startTime = strToDatetime(startDate)

        # 測定終了日
        endDate = strToDatetime(endDate)

        # 確定終端日
        fixedend = datetime.datetime.strptime(str(airportList[0].fixedend), '%Y-%m-%d')

        if endDate > fixedend:
            # 測定期間情報の編集ボタン（False：使用可）
            btnControl['spanEdit'] = False

            if len(lvwSpan) > 1 and deletableSpan(sICAO, stationId, startTime, endDate, xmlList):
                # 測定期間情報の削除ボタン（False：使用可）
                btnControl['spanDel'] = False

        for span in lvwSpan:
            if startDate == span.get('startDateHidden'):
                btnControl['sirenCut'] = span.get('sirenCut', True)

'''
 測定局［削除］ボタンクリック
 測定局情報削除
'''
def del_Click(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # アプリケーション設定値を取得する。
    xmlList = request.session.get('xmlList')

    # 測定局ID
    stationId = request.GET.get('stationId')
    
    # 測定局情報削除
    Stationlist.objects.filter(icao = sICAO, stationid = stationId).delete()

    # 測定局住所情報削除
    Addressspan.objects.filter(icao = sICAO, stationid = stationId).delete()

    # 測定期間情報削除
    Stationspan.objects.filter(icao = sICAO, stationid = stationId).delete()

    for xml in xmlList:
        if xml.get('setup').lower() == "true":
            # セットアップ情報キーの追加
            deleteSetupInfo(xml.get('setupTable'), sICAO, stationId, "")

    # 特異除外音情報削除
    Sirencut.objects.filter(icao = sICAO, stationid = stationId).delete()

    # 測定局情報を取得する。
    lvwStation = get_lvwStation(sICAO)

    # 測定局ID
    stationId = lvwStation[0].get('stationId')

    return JsonResponse({'lvwStation': lvwStation, 'stationId': stationId})

'''
 更新後の画面再描画
'''
def resetWindow(request):

    # 空港コード
    sICAO = request.session.get('sICAO')
    
    # 測定局情報を取得する。
    lvwStation = get_lvwStation(sICAO)

    # 新規する測定局ID
    stationId = request.session.get('newStationId')

    return JsonResponse({'lvwStation': lvwStation, 'stationId': stationId})

'''
 スケジュール更新後の画面再描画
'''
def resetSpanWindow(request):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = request.GET.get('stationId')

    xmlList = request.session.get('xmlList')

    # 測定期間情報を取得する。
    lvwSpan = get_lvwSpan(sICAO, stationId, xmlList)

    return JsonResponse({'lvwSpan': lvwSpan})

'''
 スケジュール［削除］ボタンクリック
 測定局スケジュール削除
'''
def spanDel_Click(request):

    xmlList = request.session.get('xmlList')

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = request.GET.get('stationId')

    # 測定開始日
    startDate = strToDatetime(request.GET.get('startDate'))

    # 測定局情報削除
    Stationspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate).delete()

    for xml in xmlList:
        if xml.get('setup').lower() == "true":
            # 指定セットアップ情報の削除
            deleteSetupInfo(xml.get('setupTable'), sICAO, stationId, startDate)

    # 測定局住所情報削除
    Addressspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate).delete()

    # 測定期間情報を取得する。
    lvwSpan = get_lvwSpan(sICAO, stationId, xmlList)

    return JsonResponse({'lvwSpan': lvwSpan})

'''
 インデックスはセッションに保存する。
'''
def saveIndex(request):
    
    # 測定局インデックス
    stationIndex = request.GET.get('stationIndex', 0)

    request.session['stationIndex'] = stationIndex

    return JsonResponse({})

from django.apps import AppConfig


class stationEditConfig(AppConfig):
    name = 'stationEdit'

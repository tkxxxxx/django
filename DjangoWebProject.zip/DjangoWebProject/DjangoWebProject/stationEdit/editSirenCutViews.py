﻿# coding:utf-8
from django.shortcuts import render
from stationEdit.models import *
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import connection
from stationEdit.stationEdit import *

import json
import datetime

'''
 画面初期表示
'''
def editSirenCut_Load(request, *args, **kwargs):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = kwargs.get('stationId')
    mode = kwargs.get('mode')
    startDate = kwargs.get('startDate', "")
    startTime = kwargs.get('startTime', "")

    content = {}
    content['stationId'] = stationId
    content['mode'] = mode

    # 測定住所情報を取得する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId).order_by('-startdate').values()
    if len(span) > 0:
        content['shortName'] = span[0].get('shortname', "")

    # コントロールへの値セット
    setControl(mode, sICAO, stationId, startDate, startTime, content)

    return render(request, "editSirenCut.html", content)

'''
 コントロールへの値セット
'''
def setControl(mode, sICAO, stationId, startDate, startTime, content):
    
    now = datetime.datetime.now()
    year = str(now.year)
    content['minDate'] = year + "-01-01"
    content['maxDate'] = year + "-12-31"

    if mode == 1:
        # 追加の場合

        # 開始日
        content['startDate'] = year + "-01-01"
        # 終了日
        content['endDate'] = year + "-12-31"
        # 開始時刻
        content['startTime'] = "11:59:00"
        # 終了時刻
        content['endTime'] = "12:01:00"
        # 削除閾値
        content['limitlasmax'] = "80.0"

    else:
        sirenCut = setSirenCutList(sICAO, stationId, startDate, startTime)

        if len(sirenCut) > 0:
            # 開始日
            content['startDate'] = sirenCut[0].get('startDateHidden')
            # 終了日
            content['endDate'] = sirenCut[0].get('endDateHidden')
            # 開始時刻
            content['startTime'] = sirenCut[0].get('startTime')
            # 終了時刻
            content['endTime'] = sirenCut[0].get('endTime')
            # 削除閾値
            content['limitlasmax'] = sirenCut[0].get('limitlasmax')

    # 変更判断用データ
    content['sDate'] = content.get('startDate')
    content['eDate'] = content.get('endDate')
    content['sTime'] = content.get('startTime')
    content['eTime'] = content.get('endTime')
    content['limit'] = content.get('limitlasmax')

'''
 特異除外音リストビューの生成
'''
def setSirenCutList(sICAO, stationId, startDate, startTime):

    resultList = []

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId

    if startDate != "" and startTime != "":
        kwargs['startdate'] = startDate
        kwargs['starttime'] = startTime

    
    # 特異除外音情報を取得する。
    sirenCutList = Sirencut.objects.filter(**kwargs).order_by('startdate', 'starttime')

    for sirenCut in sirenCutList:

        map = {}

        # 開始日の月を取得する。
        startMonth = str(sirenCut.startdate.month)
        startMonth = ("00" + startMonth)[-2:]

        # 開始日の日を取得する。
        startDay = str(sirenCut.startdate.day)
        startDay = ("00" + startDay)[-2:]

        # 開始日
        map['startDate'] = startMonth + "/" + startDay
        map['startDateHidden'] = str(sirenCut.startdate)

        # 終了日の月を取得する。
        endMonth = str(sirenCut.enddate.month)
        endMonth = ("00" + endMonth)[-2:]

        # 終了日の日を取得する。
        endDay = str(sirenCut.enddate.day)
        endDay = ("00" + endDay)[-2:]

        # 終了日
        map['endDate'] = endMonth + "/" + endDay
        map['endDateHidden'] = str(sirenCut.enddate)

        # 開始時刻
        map['startTime'] = str(sirenCut.starttime)

        # 終了時刻
        map['endTime'] = str(sirenCut.endtime)

        # 削除閾値
        map['limitlasmax'] = str(sirenCut.limitlasmax)

        resultList.append(map)

    return resultList

'''
 ［追加］/［編集］ボタンクリック
'''
@csrf_exempt
def edit_Click(request, *args, **kwargs):
    
    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = kwargs.get('stationId')
    mode = kwargs.get('mode')

    param = json.loads(request.POST.get('param'))

    if mode == 1:
        # 追加の場合

        # 特異除外音の登録
        addSirenCut(sICAO, stationId, param)
    else:
        # 特異除外音の更新
        updateSirenCut(sICAO, stationId, param)

    return JsonResponse({})

'''
 コントロールの設定値からDBテーブルにデータを追加する
'''
def addSirenCut(sICAO, stationId, param):

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = param.get('startDate')
    kwargs['enddate'] = param.get('endDate')
    kwargs['starttime'] = param.get('startTime')
    kwargs['endtime'] = param.get('endTime')
    kwargs['limitlasmax'] = float(param.get('limitlasmax'))

    # 測定期間情報を登録する。
    Sirencut.objects.create(**kwargs)

'''
 コントロールの設定値からDBテーブルのデータを更新する
'''
def updateSirenCut(sICAO, stationId, param):

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = param.get('startDateHidden')
    kwargs['starttime'] = param.get('startTimeHidden')

    # 特異除外音の削除
    sirenCutList = Sirencut.objects.filter(**kwargs).delete()
    
    # 特異除外音の登録
    addSirenCut(sICAO, stationId, param)

'''
 期間の重複チェック
 判定結果（True：既存/False：不在）
'''
@csrf_exempt
def isExists(request, *args, **kwargs):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = kwargs.get('stationId')
    mode = kwargs.get('mode')
    startDate = kwargs.get('startDate', "")
    startTime = kwargs.get('startTime', "")

    sqlParam = [sICAO, stationId]

    sql = 'SELECT'
    sql += '  ICAO, '
    sql += '  StartDate, '
    sql += '  EndDate, '
    sql += '  StartTime, '
    sql += '  EndTime, '
    sql += '  LimitLASmax '
    sql += 'FROM '
    sql += '  SirenCut '
    sql += 'WHERE '
    sql += '  ICAO = %s '
    sql += '  AND StationID = %s '

    if mode != 1:
        # 編集の場合

        sql += '  AND (StartDate <> %s '
        sql += '   OR  StartTime <> %s ) '

        sqlParam = [sICAO, stationId, startDate, startTime]

    with connection.cursor() as cursor:
        cursor.execute(sql, sqlParam)
        rows = cursor.fetchall()

    param = json.loads(request.POST.get('param'))

    # 画面から取得した開始時刻
    tStartDate = strToDatetime(param.get('startDate') + " " + param.get('startTime'))

    # 画面から取得した終了時刻
    tEndDate = strToDatetime(param.get('endDate') + " " + param.get('endTime'))
    
    for row in rows:

        # 開始時刻
        sStartDate = strToDatetime(str(row[1]) + " " + str(row[3]))

        # 終了時刻
        sEndDate = strToDatetime(str(row[2]) + " " + str(row[4]))

        if (sStartDate <= tStartDate and sEndDate >= tStartDate) or (sStartDate <= tEndDate and sEndDate >= tEndDate) or (sStartDate >= tStartDate and sEndDate <= tEndDate):
            return JsonResponse({'isExists': True})

    return JsonResponse({'isExists': False})
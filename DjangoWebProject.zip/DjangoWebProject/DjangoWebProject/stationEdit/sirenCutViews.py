﻿# coding:utf-8
from django.shortcuts import render
from stationEdit.editSirenCutViews import *
from django.http.response import JsonResponse

'''
 画面初期表示
'''
def sirenCut_Load(request, stationId):

    content = {}
    content['stationId'] = stationId

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定住所情報を取得する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId).order_by('-startdate').values()
    if len(span) > 0:
        content['shortName'] = span[0].get('shortname', "")

    # 特異除外音リストビューの生成
    sirenCutList = setSirenCutList(sICAO, stationId, "", "")

    content['sirenCutList'] = sirenCutList

    if len(sirenCutList) <= 0:
        # データが存在しない場合
        # 編集、削除ボタンが使用不可
        content['btnDisabled'] = 'disabled'

    return render(request, "sirenCut.html", content)

'''
 ［削除］ボタンクリック
'''
def delete_Click(request, stationId):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 開始日
    startDate = request.GET.get('startDate')

    # 開始時刻
    startTime = request.GET.get('startTime')

    # 特異除外音の削除
    sirenCutList = Sirencut.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate, starttime = startTime).delete()

    # 特異除外音情報を取得する。
    sirenCutList = setSirenCutList(sICAO, stationId, "", "")

    btnDisabled = ""

    if len(sirenCutList) <= 0:
        # データが存在しない場合
        # 編集、削除ボタンが使用不可
        btnDisabled = 'disabled'

    return JsonResponse({'sirenCutList': sirenCutList, 'btnDisabled': btnDisabled})

'''
 スケジュール更新後の画面再描画
'''
def resetSirenCutWindow(request, stationId):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 特異除外音リストビューの生成
    sirenCutList = setSirenCutList(sICAO, stationId, "", "")

    btnDisabled = ""

    if len(sirenCutList) <= 0:
        # データが存在しない場合
        # 編集、削除ボタンが使用不可
        btnDisabled = 'disabled'

    return JsonResponse({'sirenCutList': sirenCutList, 'btnDisabled': btnDisabled})
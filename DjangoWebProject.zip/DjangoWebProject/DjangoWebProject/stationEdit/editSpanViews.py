﻿# coding:utf-8
from django.shortcuts import render
from stationEdit.models import *
from stationEdit.stationEdit import *
from stationEdit.editStationViews import *
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from django.db.models import Max

import json

'''
 画面初期表示
'''
def editSpan_Load(request, stationId, mode, startDate):

    content = {}

    content['stationId'] = stationId
    content['startDateHidden'] = startDate
    
    xmlList = request.session.get('xmlList')

    # チェックボックス設定
    setchkMeasInitial(xmlList, content)

    # 画面コントロール初期設定
    setControlInitial(request, stationId, mode, startDate, content, xmlList)

    # ［ＤＬ型式］コンボボックス
    content['modelList'] = setcboModelInitial()

    request.session['spanContent'] = content

    return render(request, "editSpan.html", content)

'''
 画面コントロール初期設定
'''
def setControlInitial(request, stationId, mode, startDate, content, xmlList):
    
    # 現在の時間を取得する。
    now = datetime.datetime.now()

    content['startDate'] = datetimeTostr(addDays(now, -1))
    content['endDate'] = datetimeTostr(addDays(now, -1))

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定住所情報を取得する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId).order_by('-startdate').values()
    if len(span) > 0:
        content['shortName'] = span[0].get('shortname', "")

    # 空港情報を取得する。
    airportList = getAirportInfo(sICAO)

    # 確定終端日
    fixedend = datetime.datetime.strptime(str(airportList[0].fixedend), '%Y-%m-%d')

    # 最大日
    content['minDate'] = datetimeTostr(addDays(fixedend, 1))

    # 最小日
    content['maxDate'] = datetimeTostr(strToDatetime(request.session.get('SystemMaxDate')))

    if mode == 2:

        # 測定開始日
        startDate = strToDatetime(startDate)

        if startDate <= fixedend:
            mode = 1

        # コントロールに値を代入します
        setMeasItemInitial(sICAO, stationId, startDate, content, xmlList)

    if mode == 1:
        content['startDateDisabled'] = 'disabled'
        content['modelDisabled'] = 'disabled'
        content['checkboxDisabled'] = 'disabled'

    content['mode'] = mode

'''
 ＤＬ型式コンボボックス設定
'''
def setcboModelInitial():

    list = []
    
    modelList = Modellist.objects.filter(modelavailable = -1).order_by('modelno')

    for model in modelList:

        map = {}

        # 測定器型式No
        map['modelNo'] = model.modelno

        # 測定器型式名称
        map['modelName'] = model.modelname

        list.append(map)

    return list

'''
 チェックボックス設定
'''
def setchkMeasInitial(xmlList, content):
    
    content['xmlLenth'] = len(xmlList)

    index = 0

    for xml in xmlList:
        xml['checkboxName'] = "checkbox" + str(index)
        index += 1

    # 測定データを設定する。
    content['xmlList'] = xmlList

'''
 コントロールに値を代入します
'''
def setMeasItemInitial(sICAO, stationId, startDate, content, xmlList):
    
    stationSpan = Stationspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate).values()

    content['startDate'] = datetimeTostr(startDate)
    content['endDate'] = datetimeTostr(stationSpan[0].get('enddate'))
    content['modelNo'] = stationSpan[0].get('modelno')

    for xml in xmlList:
        key = xml.get('name').lower() + 'available'
        xml['checkboxVal'] = stationSpan[0].get(key)

        content[xml.get('checkboxName')] = stationSpan[0].get(key)

'''
 ［編集］ボタンクリック
'''
@csrf_exempt
def edit_Click(request, stationId, mode, startDate):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 変更前のデータ
    spanContent = request.session.get('spanContent')

    xmlList = request.session.get('xmlList')
    
    param = json.loads(request.POST.get('param'))

    mode = int(param.get('mode'))

    # 変更前開始日
    tTrgSDate = getStartDate(spanContent.get('startDate'))

    msgList = []
    warningMsg = ""

    if mode == 1:

        if changeValue(param, spanContent):
            # 変更点があった場合

            if isExistsStationSpan(sICAO, stationId, tTrgSDate):
                # 測定局の測定スケジュールが存在する場合

                # 再集計期間の警告メッセージ
                warningMsg = messeDate(sICAO, mode, param)

                # 測定スケジュール情報の指定開始日データの終了日を更新する
                updateStationSpanEndDate(sICAO, stationId, param)

                # 測定局住所情報の指定開始日データの終了日を更新する
                updateAddressSpanEndDate(sICAO, stationId, param)

    elif mode == 2:

        if changeValue(param, spanContent):
            # 変更点があった場合

            if isExistsStationSpan(sICAO, stationId, tTrgSDate):
                # 測定局の測定スケジュールが存在する場合

                # セットアップ情報の初期化事前チェック
                checkSetupInit(sICAO, stationId, tTrgSDate, param, xmlList, msgList)

                # 再集計期間の警告メッセージ
                warningMsg = messeDate(sICAO, mode, param)

                # 測定スケジュール情報を更新する
                updateStationSpan(sICAO, stationId, param, spanContent)

                # 測定局住所情報の指定開始日データの開始・終了日を更新する
                updateAddressSpan(sICAO, stationId, param, spanContent)

    elif mode == 3:
        # 追加の場合

        # StationSpanの追加の際にSetupの変更を行う
        setupAdd(sICAO, stationId, xmlList, param)

        # 再集計期間の警告メッセージ
        warningMsg = messeDate(sICAO, mode, param)

        # 測定スケジュール情報の追加
        insertStationSpan(sICAO, stationId, param, spanContent)

        if not isExistsAddressSpan(sICAO, stationId, getStartDate(param.get('startDate'))):
            # 既存の最新測定局住所情報からの追加
            insertAddressSpanFromSelect(sICAO, stationId, param)

    return JsonResponse({'msgList': msgList, 'warningMsg': warningMsg})

'''
 他のスケジュールとダブりがないかを判定し、返す
'''
def isDoubleBooking(request, stationId, mode, startDate):
    
    # 空港コード
    sICAO = request.session.get('sICAO')

    newStartDate = request.GET.get('startDate')
    endDate = request.GET.get('endDate')
    mode = int(request.GET.get('mode'))

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate__lte'] = endDate
    kwargs['enddate__gte'] = newStartDate

    if mode != 3:
        # 新規登録以外
        stationSpan = Stationspan.objects.filter(**kwargs).exclude(startdate = startDate)

    else:
        stationSpan = Stationspan.objects.filter(**kwargs)

    return JsonResponse({'spanLength': len(stationSpan)})

'''
 指定測定局・指定開始日の測定局住所情報が存在するか判定すし、返す
'''
def checkAddressSpan(request, stationId, mode, startDate):

    # 空港コード
    sICAO = request.session.get('sICAO')

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = startDate
    
    addressSpan = Addressspan.objects.filter(**kwargs)

    return JsonResponse({'spanLength': len(addressSpan)})



'''
 変更点があったかチェックを行う
'''
def changeValue(param, spanContent):

    if param.get('startDate') != spanContent.get('startDate') or param.get('endDate') != spanContent.get('endDate') or param.get('modelNo') != str(spanContent.get('modelNo')) :
        return True

    xmlLenth = spanContent.get('xmlLenth')

    index = 0

    while index < xmlLenth:
        key = "checkbox" + str(index)

        if int(param.get(key)) != int(spanContent.get(key)):
            return True

        index += 1

    return False

'''
 測定局の測定スケジュールが存在するかを判定し、返す
'''
def isExistsStationSpan(sICAO, stationId, startDate):

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = startDate
    
    stationSpan = Stationspan.objects.filter(**kwargs)

    if len(stationSpan) > 0:
        return True
    else:
        return False

'''
 指定測定局・指定開始日の測定局住所情報が存在するか判定すし、返す
'''
def isExistsAddressSpan(sICAO, stationId, startDate):

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = startDate
    
    addressSpan = Addressspan.objects.filter(**kwargs)

    if len(addressSpan) > 0:
        return True
    else:
        return False

'''
 測定スケジュール情報の指定開始日データの終了日を更新する
'''
def updateStationSpanEndDate(sICAO, stationId, param):

    # 開始日
    startDate = getStartDate(param.get('startDate'))

    # 測定期間情報を検索する。
    span = Stationspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate)
    
    # 更新項目
    kwargs = {}
    kwargs['enddate'] = getEndDate(param.get('endDate'))
    kwargs['lastupdated'] = getNowTime()

    # 測定期間情報を更新する
    span.update(**kwargs)

'''
 測定局住所情報の指定開始日データの終了日を更新する
'''
def updateAddressSpanEndDate(sICAO, stationId, param):

    # 開始日
    startDate = getStartDate(param.get('startDate'))

    # 測定住所情報を検索する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate)
    
    # 更新項目
    kwargs = {}
    kwargs['enddate'] = getEndDate(param.get('endDate'))
    kwargs['lastupdated'] = getNowTime()

    # 測定住所情報を更新する
    span.update(**kwargs)


'''
 測定スケジュール情報を更新する
'''
def updateStationSpan(sICAO, stationId, param, spanContent):

    # 変更前の開始日
    startDate = getStartDate(spanContent.get('startDate'))

    # 開始日
    newStartDate = getStartDate(param.get('startDate'))

    # 測定期間情報を検索する。
    span = Stationspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate)
    
    # 更新項目
    kwargs = {}

    kwargs['startdate'] = newStartDate
    kwargs['enddate'] = getEndDate(param.get('endDate'))
    kwargs['modelno'] = int(param.get('modelNo'))

    kwargs['noiseavailable'] = 0
    kwargs['rd90available'] = 0
    kwargs['modesavailable'] = 0
    kwargs['rd100available'] = 0
    kwargs['sd100available'] = 0

    index = 0
    for xml in spanContent.get('xmlList'):
        checkbox = "checkbox" + str(index)
        val = int(param.get(checkbox))

        key = xml.get('name').lower() + 'available'
        kwargs[key] = val

        index += 1

    kwargs['lastupdated'] = getNowTime()

    # 測定期間情報を更新する
    span.update(**kwargs)

'''
 測定局住所情報の指定開始日データの開始・終了日を更新する
'''
def updateAddressSpan(sICAO, stationId, param, spanContent):

    # 変更前の開始日
    startDate = getStartDate(spanContent.get('startDate'))

    # 開始日
    newStartDate = getStartDate(param.get('startDate'))

    # 測定住所情報を検索する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId, startdate = startDate)
    
    # 更新項目
    kwargs = {}
    kwargs['startdate'] = newStartDate
    kwargs['enddate'] = getEndDate(param.get('endDate'))
    kwargs['lastupdated'] = getNowTime()

    # 測定住所情報を更新する
    span.update(**kwargs)

'''
 測定スケジュール情報の追加
'''
def insertStationSpan(sICAO, stationId, param, spanContent):
    
    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = stationId
    kwargs['startdate'] = getStartDate(param.get('startDate'))
    kwargs['enddate'] = getEndDate(param.get('endDate'))
    kwargs['modelno'] = int(param.get('modelNo'))

    kwargs['noiseavailable'] = 0
    kwargs['rd90available'] = 0
    kwargs['modesavailable'] = 0
    kwargs['rd100available'] = 0
    kwargs['sd100available'] = 0

    index = 0
    for xml in spanContent.get('xmlList'):
        checkbox = "checkbox" + str(index)
        val = int(param.get(checkbox))

        key = xml.get('name').lower() + 'available'
        kwargs[key] = val

        index += 1

    kwargs['datecreated'] = getNowTime()
    kwargs['lastupdated'] = getNowTime()

    # 測定期間情報を登録する。
    Stationspan.objects.create(**kwargs)

'''
 既存の最新測定局住所情報からの追加
'''
def insertAddressSpanFromSelect(sICAO, stationId, param):

    sql = 'INSERT INTO AddressSpan '
    sql += ' SELECT ICAO '
    sql += '       ,StationID '
    sql += '       ,%s '
    sql += '       ,%s '
    sql += '       ,Name '
    sql += '       ,ShortName '
    sql += '       ,OwnerNo '
    sql += '       ,AreaNo '
    sql += '       ,Address '
    sql += '       ,Spot '
    sql += '       ,PublicX '
    sql += '       ,PublicY '
    sql += '       ,TEL '
    sql += '       ,EnvStandardNo '
    sql += '       ,NotifiedZoneNo '
    sql += '       ,PermOrPortable '
    sql += '       ,Memo '
    sql += '       ,%s '
    sql += '       ,%s '
    sql += ' FROM AddressSpan '
    sql += ' WHERE ICAO = %s '
    sql += '       AND StationID = %s '
    sql += '       AND StartDate = (SELECT MAX(StartDate) '
    sql += '                        FROM AddressSpan '
    sql += '                        WHERE ICAO = %s '
    sql += '                              AND StationID = %s )'

    startDate = getStartDate(param.get('startDate'))
    endDate = getEndDate(param.get('endDate'))
    now = getNowTime()

    with connection.cursor() as cursor:
        cursor.execute(sql, [startDate, endDate, now, now, sICAO, stationId, sICAO, stationId])

'''
 再集計期間の警告メッセージ
'''
def messeDate(sICAO, mode, param):

    warningMsg = ""
    
    tAnalysisEnd = lastAnalysisDate(sICAO)

    if tAnalysisEnd is None:
        warningMsg = "最終集計日の確認に失敗しました"
        return warningMsg

    # 開始日
    tStartDate = strToDatetimeWithoutHMS(param.get('startDate'))

    # 終了日
    tEndDate = strToDatetimeWithoutHMS(param.get('endDate'))

    pEndDate = str(tAnalysisEnd)

    if mode == 1:
        if tEndDate < strToDatetimeWithoutHMS(str(tAnalysisEnd)):
            warningMsg = param.get('endDate') + "から" + pEndDate + "まで再集計を行ってください。"
            return warningMsg

    else:
        
        if tStartDate < strToDatetimeWithoutHMS(str(tAnalysisEnd)) :
            if tEndDate < strToDatetimeWithoutHMS(str(tAnalysisEnd)):
                pEndDate = param.get('endDate')
            warningMsg = param.get('startDate') + "から" + pEndDate + "まで再集計を行ってください。"
            return warningMsg

    return warningMsg

'''
 ある測定局が集計された最終日の取得
'''
def lastAnalysisDate(sICAO):

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['fixed_flag'] = -1

    taskinfost = Taskinfost.objects.filter(**kwargs).aggregate(max_measdate = Max('measdate'))

    return taskinfost.get('max_measdate')

'''
 セットアップ情報の初期化事前チェック
'''
def checkSetupInit(sICAO, stationId, tStartDate, param, xmlList, msgList):

    index = 0

    for xml in xmlList:
        if param.get("checkbox" + str(index)) == -1:
            # 指定セットアップ情報が存在するかを判定
            if isExistsSetupInfo(xml.get('setupTable'), sICAO, stationId, tStartDate):
                msg = "照合用の設定(" + xml.get('setupTable') + ")を変更しようとしています。\nパラメータを独自に変更している場合、\n再設定が必要となりますのでご注意ください。"
                msgList.append(msg)

        index += 1

'''
 StationSpanの追加の際にSetupの変更を行う
'''
def setupAdd(sICAO, stationId, xmlList, param):

    # 変更後開始日
    tStartDate = getStartDate(param.get('startDate'))

    index = 0

    for xml in xmlList:

        # 対象セットアップパラメータ名称
        setupTable = xml.get('setupTable')

        # 指定セットアップ情報の削除
        deleteSetupInfo(setupTable, sICAO, stationId, tStartDate)

        if param.get("checkbox" + str(index)) == -1:
    
            # セットアップ情報キーの追加
            insertSetupInfo(setupTable, sICAO, stationId, tStartDate)

        index += 1

'''
 StationSpanの編集の際にSetupの変更を行う
'''
@csrf_exempt
def setupEdit(request, stationId, mode, startDate):

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 変更前のデータ
    spanContent = request.session.get('spanContent')

    xmlList = request.session.get('xmlList')

    param = json.loads(request.POST.get('param'))

    arrayList = param.get('arrayList')
    
    # 変更後開始日
    tStartDate = getStartDate(param.get('startDate'))

    # 変更前開始日
    tTrgSDate = getStartDate(spanContent.get('startDate'))

    index = 0
    arrayIndex = 0

    for xml in xmlList:

        # 対象セットアップパラメータ名称
        setupTable = xml.get('setupTable')

        if param.get("checkbox" + str(index)) == -1:

            if param.get('startDate') == spanContent.get('startDate'):
                # 開始日の変更はなし
                
                if isExistsSetupInfo(setupTable, sICAO, stationId, tTrgSDate):
                    # 指定セットアップ情報が存在するかを判定

                    if arrayList[arrayIndex]:

                        # 初期化（削除＆追加）
                        deleteSetupInfo(setupTable, sICAO, stationId, tTrgSDate)

                        insertSetupInfo(setupTable, sICAO, stationId, tStartDate)

                else:
                    # 既存の情報なし

                    insertSetupInfo(setupTable, sICAO, stationId, tStartDate)

            else:
                # 開始日の変更あり

                if isExistsSetupInfo(setupTable, sICAO, stationId, tTrgSDate):
                    # 指定セットアップ情報が存在するかを判定

                    if arrayList[arrayIndex]:

                        # 初期化（削除＆追加）
                        deleteSetupInfo(setupTable, sICAO, stationId, tTrgSDate)

                        insertSetupInfo(setupTable, sICAO, stationId, tStartDate)

                    else:
                        # 開始日更新
                        updateSetupInfoStartDate(setupTable, sICAO, stationId, tStartDate, tTrgSDate)

                else:
                    # 既存の情報なし

                    insertSetupInfo(setupTable, sICAO, stationId, tStartDate)

            arrayIndex += 1

        else:
            # チェックボックスoff

            # ここでは削除は行わない
            updateSetupInfoStartDate(setupTable, sICAO, stationId, tStartDate, tTrgSDate)
        
        index += 1

    return JsonResponse({})


'''
 指定セットアップ情報が存在するかを判定し、返す
'''
def isExistsSetupInfo(setupTable, sICAO, stationId, tStartDate):
    
    sql = 'SELECT * '
    sql += ' FROM '
    sql += setupTable
    sql += ' WHERE ICAO = %s '
    sql += ' AND StationID = %s '
    sql += ' AND StartDate = %s '   

    with connection.cursor() as cursor:
        cursor.execute(sql, [sICAO, stationId, tStartDate])
        rows = cursor.fetchall()

    if len(rows) > 0:
        return True
    else:
        return False

'''
 セットアップ情報開始日の更新
'''
def updateSetupInfoStartDate(setupTable, sICAO, stationId, tStartDate, tTrgSDate):

    sql = 'UPDATE '
    sql += setupTable
    sql += ' SET StartDate = %s '
    sql += ' WHERE ICAO = %s '
    sql += ' AND StationID = %s '
    sql += ' AND StartDate = %s ' 

    with connection.cursor() as cursor:
        cursor.execute(sql, [tStartDate, sICAO, stationId, tTrgSDate])

def getStartDate(str):
    return strToDatetime(str + " 00:00:00")

def getEndDate(str):
    return strToDatetime(str + " 23:59:59")
﻿# coding:utf-8
from django.shortcuts import render
from stationEdit.models import *
from stationEdit.stationEdit import *
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Max

import json
import datetime

'''
 画面初期表示
'''
def editStation_Load(request, stationId, mode, index):

    content = {}
    content['stidHidden'] = stationId
    content['mode'] = mode
    content['index'] = index

    # 測定局ID
    request.session['stationId'] = stationId

    # ［所有者］コンボボックス
    content['ownerList'] = setcboOwnerInitial()

    # ［環境基準］コンボボックス
    content['envList'] = setcboEnvStandardInitial()

    # ［告示区域］コンボボックス
    content['zoneList'] = setcboNotifiedZoneInitial()

    # ［地域］コンボボックス
    content['areaList'] = setcboAreaInitial()

    setMode(mode, content)

    if mode == 2:
        # 追加の場合

        # 新規する測定局ID
        request.session['newStationId'] = ""

        content['title'] = "追加"

        # 測定局種別（移動局を固定）
        content['permOrPortable'] = 1

        return render(request, "editStation.html", content)

    # 空港コード
    sICAO = request.session.get('sICAO')

    # コントロールに値を代入する
    dataInput(sICAO, stationId, content)

    return render(request, "editStation.html", content)

def setMode(mode, content):

    # 測定局種別
    content['permDisabled'] = 'disabled'

    if mode == 0:
        # 「詳細をみる」の場合
        content['idDisabled'] = 'disabled'
        content['aliasDisabled'] = 'disabled'
        content['selDisabled'] = 'disabled'
        content['nameDisabled'] = 'disabled'
        content['shortDisabled'] = 'disabled'
        content['ownerDisabled'] = 'disabled'
        content['areaDisabled'] = 'disabled'
        content['addDisabled'] = 'disabled'
        content['spotDisabled'] = 'disabled'
        content['xDisabled'] = 'disabled'
        content['yDisabled'] = 'disabled'
        content['telDisabled'] = 'disabled'
        content['envDisabled'] = 'disabled'
        content['zoneDisabled'] = 'disabled'

    elif mode == 1:
        # 「編集」の場合
        content['idDisabled'] = 'disabled'

        content['title'] = "編集"

'''
 ［測定局所有者］コンボボックス初期セット
'''
def setcboOwnerInitial():

    list = []

    # 所有者情報マスタを検索する。
    resultList = Ownerlist.objects.all().order_by('ownerno')

    if len(resultList) > 0:

        for owner in resultList:

            map = {}

            # 所有者No
            map['ownerNo'] = owner.ownerno

            # 所有者
            map['owner'] = owner.owner

            list.append(map)

    return list

'''
 ［環境基準］コンボボックス初期セット
'''
def setcboEnvStandardInitial():

    list = []

    # 環境基準マスタを検索する。
    resultList = Envstandard.objects.all().order_by('envstandardno')

    if len(resultList) > 0:

        for env in resultList:

            map = {}

            # 類型No
            map['envStandardNo'] = env.envstandardno

            # 類型
            map['envStandardType'] = env.envstandardtype

            list.append(map)

    return list

'''
 ［告示区域］コンボボックス初期セット
'''
def setcboNotifiedZoneInitial():

    list = []

    # 告知区分マスタを検索する。
    resultList = Notifiedzone.objects.all().order_by('notifiedzoneno')

    if len(resultList) > 0:

        for zone in resultList:

            map = {}

            # 告知区分No
            map['notifiedZoneNo'] = zone.notifiedzoneno

            # 告知区分
            map['notifiedZoneClass'] = zone.notifiedzoneclass

            list.append(map)

    return list

'''
 ［地域］コンボボックス初期セット
'''
def setcboAreaInitial():

    list = []

    # 地域情報マスタを検索する。
    resultList = Arealist.objects.all().order_by('areano')

    if len(resultList) > 0:

        for area in resultList:

            map = {}

            # 地域No
            map['areaNo'] = area.areano

            # エリア名
            map['area'] = area.area

            list.append(map)

    return list

'''
 ［＜］［＞］ボタンキー番号初期設定
'''
def setupdKeyNoInitial():
    pass

'''
 コントロールに値を代入する
'''
def dataInput(sICAO, stationId, content):

    # 測定局情報を取得する。
    stationList = Stationlist.objects.filter(icao = sICAO, stationid = stationId)

    if len(stationList) > 0:
        # データが存在する場合

        # 測定住所情報を取得する。
        span = Addressspan.objects.filter(icao = sICAO, stationid = stationId).order_by('-startdate')

        if len(span) > 0:
            # データが存在する場合

            # 測定局ID
            content['stationId'] = span[0].stationid

            # 別名
            content['alias'] = stationList[0].alias

            # 選択状態
            content['selected'] = stationList[0].selected

            # 測定局名称
            content['name'] = span[0].name

            # 測定局通称
            content['shortName'] = span[0].shortname

            # 測定局種別
            content['permOrPortable'] = span[0].permorportable

            # 所有者
            content['ownerNo'] = span[0].ownerno

            # 地域
            content['areaNo'] = span[0].areano

            # 住所
            content['address'] = span[0].address

            # 測定地点
            content['spot'] = span[0].spot

            # 公共X、Y
            x = span[0].publicx
            y = span[0].publicy
            content['publicX'] = [str(x),int(x)][int(x) == x]
            content['publicY'] = [str(y),int(y)][int(y) == y]

            # TEL
            content['tel'] = span[0].tel

            # 環境基準
            content['envStandardNo'] = span[0].envstandardno

            # 告示区域
            content['notifiedZoneNo'] = span[0].notifiedzoneno

            # 開始日
            content['startDate'] = str(span[0].startdate)

'''
 ボタン制御
'''
def buttonControl(sICAO, stationId, nUpDown):

    # ボタン制御（True：使用不可、False：使用可）
    btnControl = {}

    # 測定局情報を取得する。
    stationList = Stationlist.objects.filter(icao = sICAO).order_by('sortkey')

    list_len = len(stationList) - 1
    index = 0

    for info in stationList:
        if stationId == info.stationid:
            break

        index += 1

    index += nUpDown

    # 新しい測定局IDを取得する。
    stid = stationList[index].stationid
    btnControl['stidHidden'] = stid

    # ボタン制御（True：使用不可、False：使用可）
    if list_len == 1:
        btnControl['upBtn'] = True
        btnControl['downBtn'] = True
    else:
        if index == 0:
            btnControl['upBtn'] = True
            btnControl['downBtn'] = False
        elif index > 0 and index < list_len:
            btnControl['upBtn'] = False
            btnControl['downBtn'] = False
        elif index == list_len:
            btnControl['upBtn'] = False
            btnControl['downBtn'] = True

    return btnControl



'''
 ［＜］ボタンクリック
'''
def updKeyNo_Down_Click(request):
    pUpDown(-1)

    # ボタン制御
    btnControl = buttonControl(request, -1)

    return JsonResponse(btnControl)

'''
 ［＞］ボタンクリック
'''
def updKeyNo_Up_Click(request):
    pUpDown(1)

    # ボタン制御
    btnControl = buttonControl(request, 1)

    return JsonResponse(btnControl)

'''
 測定局情報編集画面を再描画する。
'''
def pUpDown(request, *args, **kwargs):

    content = {}

    nUpDown = int(request.GET.get('nUpDown', 0))

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 測定局ID
    stationId = request.session.get('stationId')

    # ボタン制御
    btnControl = buttonControl(sICAO, stationId, nUpDown)

    content['btnControl'] = btnControl

    newStationId = btnControl.get('stidHidden')

    request.session['stationId'] = newStationId

    if nUpDown != 0:
        # コントロールに値を代入する
        dataInput(sICAO, newStationId, content)

    return JsonResponse(content)

'''
 ［編集］ボタンクリック
  登録・編集を行う
  1:編集/2:追加
'''
@csrf_exempt
def edit_Click(request, stationId, mode, index):
    
    # 新規する測定局ID
    request.session['newStationId'] = ""

    param = json.loads(request.POST.get('param'))

    # 空港コード
    sICAO = request.session.get('sICAO')

    # 現在の時間を取得する。
    now = getNowTime()
    param['now'] = now

    if mode == 1:
        # 編集の場合

        # 測定局情報の更新
        updateStationList(sICAO, stationId, param)

        # 測定局住所情報の更新
        updateAddressSpan(sICAO, stationId, param)

    elif mode == 2:
        # 追加の場合

        # 最大ソートNo.を取得
        lSortKeyNo = getMaxSortNo(sICAO) + 1

        # 測定局情報の追加
        insertStationList(sICAO, lSortKeyNo, param)

        SystemMinDate = request.session.get('SystemMinDate')

        SystemMaxDate = request.session.get('SystemMaxDate')

        # 測定開始日時を取得する。
        tStartDate = getStartDate(sICAO, SystemMinDate)

        # 測定局住所情報の追加
        insertAddressSpan(sICAO, tStartDate, SystemMaxDate, param)

        # アプリケーション設定値を取得する。
        xmlList = request.session.get('xmlList')

        # 測定スケジュール情報の追加
        insertStationSpan(sICAO, tStartDate, SystemMaxDate, param, xmlList)
    
        # セットアップ情報初期追加
        insertSetupInitialInfo(sICAO, tStartDate, param, xmlList)

        # 新規する測定局ID
        request.session['newStationId'] = param.get('stationId')

    return JsonResponse({})

'''
 測定局情報の更新
'''
def updateStationList(sICAO, stationId, param):

    # 別名
    p_alias = param.get('alias')

    # 選択状態
    p_selected = int(param.get('selected'))

    now = param.get('now')

    # 測定局情報を検索する。
    stationInfo = Stationlist.objects.filter(icao = sICAO, stationid = stationId)

    # 測定局情報を更新する
    stationInfo.update(alias = p_alias, selected = p_selected, lastupdated = now)


'''
 測定局住所情報の更新
'''
def updateAddressSpan(sICAO, stationId, param):

    # 開始日
    p_startDate = datetime.datetime.strptime(param.get('startDate'), '%Y-%m-%d %H:%M:%S')

    # 測定住所情報を検索する。
    span = Addressspan.objects.filter(icao = sICAO, stationid = stationId, startdate = p_startDate)

    # 更新項目
    kwargs = {}

    # 測定局名称
    kwargs['name'] = param.get('fullName')
    # 測定局通称
    kwargs['shortname'] = param.get('shortName')
    # 所有者
    kwargs['ownerno'] = int(param.get('owner'))
    # 地域
    kwargs['areano'] = int(param.get('area'))
    # 住所
    kwargs['address'] = param.get('address')
    # 測定地点
    kwargs['spot'] = param.get('spot')
    # 公共X
    kwargs['publicx'] = float(param.get('publicX'))
    # 公共Y
    kwargs['publicy'] = float(param.get('publicY'))
    # TEL
    kwargs['tel'] = param.get('tel')
    # 環境基準
    kwargs['envstandardno'] = int(param.get('env'))
    # 告示区域
    kwargs['notifiedzoneno'] = int(param.get('zone'))
    kwargs['lastupdated'] = param.get('now')

    # 測定局情報を更新する
    span.update(**kwargs)

'''
 指定空港の測定局中、最大のソートNo.を返す
'''
def getMaxSortNo(sICAO):
    
    station = Stationlist.objects.filter(icao = sICAO).aggregate(max_sortkey = Max('sortkey'))

    return station['max_sortkey']

'''
 測定局情報の追加
'''
def insertStationList(sICAO, nSortKey, param):

    # 登録項目
    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = param.get('stationId')
    kwargs['alias'] = param.get('alias')
    kwargs['sortkey'] = nSortKey
    kwargs['selected'] = int(param.get('selected'))
    kwargs['datecreated'] = param.get('now')
    kwargs['lastupdated'] = param.get('now')

    # 測定局情報を登録する。
    Stationlist.objects.create(**kwargs)

'''
 測定局住所情報の追加
'''
def insertAddressSpan(sICAO, tStartDate, SystemMaxDate, param):

    # 登録項目
    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = param.get('stationId')
    kwargs['startdate'] = tStartDate
    kwargs['enddate'] = strToDatetime(SystemMaxDate)
    # 測定局名称
    kwargs['name'] = param.get('fullName')
    # 測定局通称
    kwargs['shortname'] = param.get('shortName')
    # 所有者
    kwargs['ownerno'] = int(param.get('owner'))
    # 地域
    kwargs['areano'] = int(param.get('area'))
    # 住所
    kwargs['address'] = param.get('address')
    # 測定地点
    kwargs['spot'] = param.get('spot')
    # 公共X
    kwargs['publicx'] = float(param.get('publicX'))
    # 公共Y
    kwargs['publicy'] = float(param.get('publicY'))
    # TEL
    kwargs['tel'] = param.get('tel')
    # 環境基準
    kwargs['envstandardno'] = int(param.get('env'))
    # 告示区域
    kwargs['notifiedzoneno'] = int(param.get('zone'))
    # 測定局種別
    kwargs['permorportable'] = int(param.get('permOrPortable'))
    kwargs['datecreated'] = param.get('now')
    kwargs['lastupdated'] = param.get('now')
    
    # 測定住所情報を登録する。
    Addressspan.objects.create(**kwargs)


'''
 測定開始日時を取得する。
'''
def getStartDate(sICAO, SystemMinDate):
    
    # 空港情報を取得する。
    airportList = getAirportInfo(sICAO)

    # 確定終端日
    fixedend = datetime.datetime.strptime(str(airportList[0].fixedend), '%Y-%m-%d')

    # 翌日を取得する。
    tStartDate = fixedend + datetime.timedelta(1)

    sysMinDate = strToDatetime(SystemMinDate)

    if tStartDate < sysMinDate:
        tStartDate = sysMinDate

    return tStartDate

'''
 測定スケジュール情報の追加
'''
def insertStationSpan(sICAO, tStartDate, SystemMaxDate, param, xmlList):
    
    # DLモデル番号を取得する
    nModelNo = getMinAvailableDLModelNo()

    # 更新時間
    now = param.get('now')

    kwargs = {}
    kwargs['icao'] = sICAO
    kwargs['stationid'] = param.get('stationId')
    kwargs['startdate'] = tStartDate
    kwargs['enddate'] = strToDatetime(SystemMaxDate)
    kwargs['modelno'] = nModelNo

    kwargs['noiseavailable'] = 0
    kwargs['rd90available'] = 0
    kwargs['modesavailable'] = 0
    kwargs['rd100available'] = 0
    kwargs['sd100available'] = 0

    for xml in xmlList:
        key = xml.get('name').lower() + 'available'
        kwargs[key] = -1

    kwargs['datecreated'] = param.get('now')
    kwargs['lastupdated'] = param.get('now')

    # 測定期間情報を登録する。
    Stationspan.objects.create(**kwargs)

'''
 有効なDLモデルで最小のモデル番号を取得する
 <returns>有効最小のDLモデル番号</returns>
'''
def getMinAvailableDLModelNo():

    nRet = -1

    modellist = Modellist.objects.all().exclude(modelavailable = 0)

    if len(modellist) > 0:
        nRet = modellist[0].modelno

    return nRet

'''
 セットアップ情報初期追加
'''
def insertSetupInitialInfo(sICAO, tStartDate, param, xmlList):
    
    for xml in xmlList:
        if xml.get('setup').lower() == "true":
            # セットアップ情報キーの追加
            insertSetupInfo(xml.get('setupTable'), sICAO, param.get('stationId'), tStartDate.strftime('%Y-%m-%d %H:%M:%S'))

'''
 セットアップ情報キーの追加
'''
def insertSetupInfo(setupTable, sICAO, stationId, tStartDate):

    sql = 'INSERT INTO '
    sql += setupTable
    sql += ' ( '
    sql += ' ICAO, '
    sql += ' StationID, '
    sql += ' StartDate '
    sql += ' ) VALUES ( '
    sql += ' %s, '
    sql += ' %s, '
    sql += ' %s '
    sql += ' );'

    with connection.cursor() as cursor:
        cursor.execute(sql, [sICAO, stationId, tStartDate])

'''
 指定セットアップ情報の削除
'''
def deleteSetupInfo(setupTable, sICAO, stationId, tStartDate):

    param = [sICAO, stationId]
    
    sql = 'DELETE FROM '
    sql += setupTable
    sql += ' WHERE ICAO = %s '
    sql += ' AND StationID = %s '

    if tStartDate:
        sql += ' AND StartDate = %s '
        param = [sICAO, stationId, tStartDate]

    with connection.cursor() as cursor:
        cursor.execute(sql, param)

'''
 測定局情報が存在するかを判定し、返す
'''
def isExistsStationList(request, *args, **kwargs):

    # 空港コード
    sICAO = request.session.get('sICAO')
    
    # 測定局ID
    stationId = request.GET.get('stationId')

    # 測定局情報を取得する。
    stationlist = Stationlist.objects.filter(icao = sICAO, stationid = stationId)

    return JsonResponse({'stationlist': len(stationlist)})
﻿# coding:utf-8
from django.db import models

'''
 空港情報マスタ
'''
class Airportlist(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    airportname = models.CharField(max_length=50, blank=True, null=True)
    legalname = models.CharField(max_length=50, blank=True, null=True)
    dirtype = models.DecimalField(max_digits=2, decimal_places=0, blank=True, null=True, default=0)
    fixedend = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'airportlist'

'''
 測定局情報
'''
class Stationlist(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    alias = models.CharField(max_length=10, blank=True, null=True)
    sortkey = models.DecimalField(max_digits=3, decimal_places=0)
    selected = models.DecimalField(max_digits=1, decimal_places=0, default=-1)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'stationlist'
        unique_together = (('icao', 'stationid'),)

'''
 測定住所情報
'''
class Addressspan(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    startdate = models.DateTimeField()
    enddate = models.DateTimeField()
    name = models.CharField(max_length=50, blank=True, null=True)
    shortname = models.CharField(max_length=50, blank=True, null=True)
    ownerno = models.DecimalField(max_digits=5, decimal_places=0)
    areano = models.DecimalField(max_digits=2, decimal_places=0)
    address = models.CharField(max_length=50, blank=True, null=True)
    spot = models.CharField(max_length=50, blank=True, null=True)
    publicx = models.FloatField()
    publicy = models.FloatField()
    tel = models.CharField(max_length=13, blank=True, null=True)
    envstandardno = models.DecimalField(max_digits=2, decimal_places=0)
    notifiedzoneno = models.DecimalField(max_digits=2, decimal_places=0)
    permorportable = models.DecimalField(max_digits=1, decimal_places=0)
    memo = models.TextField(blank=True, null=True)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'addressspan'
        unique_together = (('icao', 'stationid', 'startdate'),)

'''
 測定期間情報
'''
class Stationspan(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    startdate = models.DateTimeField()
    enddate = models.DateTimeField()
    modelno = models.DecimalField(max_digits=2, decimal_places=0)
    noiseavailable = models.DecimalField(max_digits=1, decimal_places=0)
    rd90available = models.DecimalField(max_digits=1, decimal_places=0)
    modesavailable = models.DecimalField(max_digits=1, decimal_places=0)
    rd100available = models.DecimalField(max_digits=1, decimal_places=0)
    sd100available = models.DecimalField(max_digits=1, decimal_places=0)
    sbmsid = models.CharField(max_length=4, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'stationspan'
        unique_together = (('icao', 'stationid', 'startdate'),)

'''
 測定器型式リスト
'''
class Modellist(models.Model):
    modelno = models.DecimalField(primary_key=True, max_digits=2, decimal_places=0)
    modelname = models.CharField(max_length=50)
    modelavailable = models.DecimalField(max_digits=1, decimal_places=0)

    class Meta:
        managed = False
        db_table = 'modellist'

'''
 欠測期間情報
'''
class Missspan(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    starttime = models.DateTimeField()
    endtime = models.DateTimeField(blank=True, null=True)
    noise = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd90 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    modes = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd100 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sd100 = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sbm = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    reason = models.DecimalField(max_digits=2, decimal_places=0, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    datecreated = models.DateTimeField(blank=True, null=True)
    lastupdated = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'missspan'
        unique_together = (('icao', 'stationid', 'starttime'),)

'''
 測定局動作ログ
'''
class Taskinfost(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    measdate = models.DateField()
    noise_regdate = models.DateTimeField(blank=True, null=True)
    noise_flag = models.DecimalField(max_digits=1, decimal_places=0)
    lae_regdate = models.DateTimeField(blank=True, null=True)
    lae_flag = models.DecimalField(max_digits=1, decimal_places=0)
    environ_regdate = models.DateTimeField(blank=True, null=True)
    environ_flag = models.DecimalField(max_digits=1, decimal_places=0)
    rd90_regdate = models.DateTimeField(blank=True, null=True)
    rd90_flag = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    rd100_regdate = models.DateTimeField(blank=True, null=True)
    rd100_flag = models.IntegerField()
    modes_regdate = models.DateTimeField(blank=True, null=True)
    modes_flag = models.DecimalField(max_digits=1, decimal_places=0, blank=True, null=True)
    sbm_regdate = models.DateTimeField(blank=True, null=True)
    sbm_flag = models.DecimalField(max_digits=1, decimal_places=0)
    noise_rd100_regdate = models.DateTimeField(blank=True, null=True)
    noise_rd100_flag = models.DecimalField(max_digits=1, decimal_places=0)
    onfit_regdate = models.DateTimeField(blank=True, null=True)
    onfit_flag = models.DecimalField(max_digits=1, decimal_places=0)
    adjust_regdate = models.DateTimeField(blank=True, null=True)
    adjust_flag = models.DecimalField(max_digits=1, decimal_places=0)
    listen_regdate = models.DateTimeField(blank=True, null=True)
    listen_flag = models.DecimalField(max_digits=1, decimal_places=0)
    fixed_regdate = models.DateTimeField(blank=True, null=True)
    fixed_flag = models.DecimalField(max_digits=1, decimal_places=0)
    stats_regdate = models.DateTimeField(blank=True, null=True)
    stats_flag = models.DecimalField(max_digits=1, decimal_places=0)

    class Meta:
        managed = False
        db_table = 'taskinfost'
        unique_together = (('icao', 'stationid', 'measdate'),)

'''
 所有者情報マスタ
'''
class Ownerlist(models.Model):
    ownerno = models.DecimalField(primary_key=True, max_digits=4, decimal_places=0)
    owner = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ownerlist'

'''
 環境基準マスタ
'''
class Envstandard(models.Model):
    envstandardno = models.DecimalField(primary_key=True, max_digits=2, decimal_places=0)
    envstandardtype = models.CharField(max_length=50, blank=True, null=True)
    envstandardvalue = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'envstandard'

'''
 告知区分マスタ
'''
class Notifiedzone(models.Model):
    notifiedzoneno = models.DecimalField(primary_key=True, max_digits=2, decimal_places=0)
    notifiedzoneclass = models.CharField(max_length=50)
    notifiedzonevalue = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'notifiedzone'

'''
 地域情報マスタ
'''
class Arealist(models.Model):
    areano = models.DecimalField(primary_key=True, max_digits=2, decimal_places=0)
    area = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'arealist'

'''
 サイレン音除外処理パラメータ
'''
class Sirencut(models.Model):
    icao = models.CharField(primary_key=True, max_length=4)
    stationid = models.CharField(max_length=4)
    startdate = models.DateField()
    enddate = models.DateField()
    starttime = models.TimeField()
    endtime = models.TimeField()
    limitlasmax = models.FloatField()

    class Meta:
        managed = False
        db_table = 'sirencut'
        unique_together = (('icao', 'stationid', 'startdate', 'starttime'),)
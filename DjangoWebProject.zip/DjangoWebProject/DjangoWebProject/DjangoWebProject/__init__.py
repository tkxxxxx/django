"""
Package for DjangoWebProject.
"""
